# BioMorphX (`biomorphx` v1.0.0)

**Cross-Scale Mechano-Genomic, Biomaterial, Nanofabrication & Biomedical Engineering Python Library**

---

## Why `pip install biomorphx` Did Not Work on Another Laptop Yet (And How to Fix It in 10 Seconds)

When you run `pip install biomorphx` on a new laptop without a file path, `pip` searches the public **PyPI server (`pypi.org`)**. Because this is a brand-new custom library created inside your private workspace, it is not on public PyPI until you either:

### Option A: Install Directly on Your Friend's Laptop from This Folder (Works Offline Immediately)
Send this folder (or `biomorphx-1.0.0-py3-none-any.whl`) to your friend's laptop and run **one** of these commands in their terminal / command prompt:

```bash
# Method 1: Install the pre-built Wheel file directly
pip install ./dist/biomorphx-1.0.0-py3-none-any.whl

# Method 2: Or install directly from the folder root
pip install .
```

### Option B: Make `pip install biomorphx` Publicly Available Worldwide on PyPI (`pypi.org`)
To publish `biomorphx` to the official public Python Package Index so anyone in the world can run `pip install biomorphx`:

1. Create a free account at [https://pypi.org/account/register/](https://pypi.org/account/register/) and generate an API token under **Account Settings -> API tokens**.
2. On your laptop, open this folder in a terminal and run:
```bash
pip install --upgrade build twine
python -m twine upload dist/*
```
3. Enter `__token__` as the username and your PyPI API token (`pypi-...`) as the password. Once uploaded, **anyone on any laptop worldwide** can simply run:
```bash
pip install biomorphx
```

### Option C: Install Directly from a Public GitHub Repository
If you push this folder to a public GitHub repository (e.g. `https://github.com/<your-username>/biomorphx`), your friend can install it from anywhere via:
```bash
pip install git+https://github.com/<your-username>/biomorphx.git
```
